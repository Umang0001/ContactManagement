import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  constructor() { }

  users=[
    {id:1,name:"Umang",password:"123",contacts:[
      {name:"bhagyashri",phone:"123"},
      {name:"fravash",phone:"456"},
      {name:"Amina",phone:"253"},
    ]},
    {id:2,name:"Sam",password:"123",contacts:[
      {name:"bhagyashri",phone:"123"},
      {name:"fravash",phone:"456"},
      {name:"Amina",phone:"253"},
    ]},
    {id:3,name:"Peter",password:"123",contacts:[
      {name:"bhagyashri",phone:"123"},
      {name:"fravash",phone:"456"},
      {name:"Amina",phone:"253"},
    ]},
  ]

  validateLogin(name:any,password:any) {
    let user;
    this.users.forEach(e=>{
      if (e.name===name && e.password===password) {
        user=e
      }
    })
    if (user) {
      return user
    }
    else{
      return false
    }
  }

  addContact(contact:any){

  }
}
