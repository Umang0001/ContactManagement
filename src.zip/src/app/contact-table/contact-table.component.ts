import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-table',
  templateUrl: './contact-table.component.html',
  styleUrls: ['./contact-table.component.css']
})
export class ContactTableComponent implements OnInit {

  constructor() { 
    
    let loggedInUser=JSON.parse(localStorage.getItem("loggedInUser")!)
    this.contacts=loggedInUser.contacts
  }

  ngOnInit(): void {
  }

  contacts  :{name:string,phone:string}[]=[]
}
